#age calculation fully completed
name = input("what is your name?")
birth = int(input("when were you born?"))
year = int(input("what year is it?"))
print("you are", year-birth-1, "or", year-birth, "years old.")
