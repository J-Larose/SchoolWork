days = int(input("how many days?"))
print(days, "days is euqivilent to", days*8640, "seconds,", days/7, "weeks,", days/30, "months, and", days/365, "years")