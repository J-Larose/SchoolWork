Assignment 1
Jacob Larose
101013798

Purpose: to insert user provided integers into an array in acending order, then remove user entered integers from said array

tar includes a1.c and README.txt

To compile: gcc -o a1x a1.c

To launch/operate: Execute a1x
Enter integers to be added one per line, enter a negative integer or reach the max size of the array to continue.  
Enter intergers to be removed one per line, enter a negative integer or empty the array the end the program.