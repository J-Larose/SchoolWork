Assignment 5
Jacob Larose
101013798

Purpose: this program creates and prints an array of students
 

tar includes: a5.c and README.txt

To compile: gcc -o a5x a5.c

To launch/operate: Execute a5x
enter 1 to add a student
enter the name, id and id
enter 1 to add another movie course
enter the course code, then the grade as a number
enter 1 to add another course, or 0 to move on
enter 1 to add another student, or 0 to print all the students and terminate the program