Assignment 4
Jacob Larose
101013798

Purpose: this program creates and prints an array of movies
 

tar includes: a4Posted.c and README.txt

To compile: gcc -o a4x a4Posted.c

To launch/operate: Execute a2x
enter 1 to add a movie
enter the title, director, year of release (must be after 1895) and genre.
enter 1 to add another movie, or 0 to print all the data for movies entered and terminate the program.