Assignment 2
Jacob Larose
101013798

Purpose: this program calculates a students final grade based on sub-grades and their value
 

tar includes: a2.c and README.txt

To compile: gcc -o a2x a2.c

To launch/operate: Execute a2x
Enter the value of the grades one per line, enter a negative integer  to continue.  
Enter the grades one per line, enter a negative integer to calculate/print the avg and end the program.