Assignment 7
Jacob Larose
101013798

Purpose: this program creates and prints an link list of cats
 

tar includes: a7Main.c, a7Defs.h, a7Inits.c, a7Util.c, makefile and README.txt

To compile: make a7

To launch/operate: Execute a7x
enter 1 to add a cat
enter the name, id and gender
enter 1 to add another cat, or 0 to print all the cats and terminate the program