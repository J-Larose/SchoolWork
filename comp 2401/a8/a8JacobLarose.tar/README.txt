Assignment 8
Jacob Larose
101013798

Purpose: this program allows users to chat
 

tar includes: a8.c, a8Defs.h, a8Setup.c, a8Util.c, makefile and README.txt

To compile: make 

To launch/operate: Execute a8x
type wait to wait for a connection
type talk to connect-- enter 127.0.0.1 for ip and port 60002
when prompted, type your message
type close to stop chating
repeat from step 1 or type exit to quit