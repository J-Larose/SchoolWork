Jacob Larose
assignment 4
101013798

Developed on windows 10 with chrome browser version 54.0.2840.71 m
to run: launch app.js with node, navigate to port 2406 on localhost, enter new username click ok. Type messages and press enter to send.