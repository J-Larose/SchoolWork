Jacob Larose
assignment 2 
101013798

Developed on windows 10 
to run: launch a2server.js with node, navigate to port 2406 on localhost, select a recipe, press fetch, make any changes and press submit.