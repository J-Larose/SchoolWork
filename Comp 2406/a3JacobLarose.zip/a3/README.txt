Jacob Larose
assignment 3
101013798

Developed on windows 10 with chrome browser version 54.0.2840.71 m
to run: launch app.js with node, navigate to port 2406 on localhost, enter new username click submit, click cards in pairs.  To avoid glitches wait for the animations before selecting the next card (not always neccessary but recomended)
note: the game does not end, just gets bigger