Assignment 1
Jacob Larose 
101013798

notes:

-tree constructor can be called as tree() or Tree()
-treeMap() takes string as argument and supports add, substract, multiply, divide, and square 