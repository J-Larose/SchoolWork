Jacob Larose
assignment 5
101013798

Developed on windows 10 with chrome browser version 54.0.2840.71 m
to run: launch app.js with node, navigate to port 2406 on localhost. either load a recipe or enter a new one.